/**
 * Twikoo EdgeOne Makers 函数入口。
 *
 * 平台按 cloud-functions/ 目录生成路由，本文件映射到 PATH: /。
 * 实现全部来自 npm 上的 @twikoojs/edgeone-makers（平台会 npm install 并内联进函数单文件），
 * 因此升级 Twikoo 只需在本项目点「重新部署」，无需重新上传部署包。
 */
export { onRequest, onRequest as default } from "@twikoojs/edgeone-makers";
